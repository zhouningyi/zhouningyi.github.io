 
 define(function(require, exports, module) {
 var Controller = require('./controller');
 new Controller($('.container'));
});
